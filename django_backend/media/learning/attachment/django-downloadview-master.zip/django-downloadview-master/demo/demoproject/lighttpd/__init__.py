"""Lighttpd optimizations."""
