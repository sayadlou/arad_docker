# -*- coding: utf-8 -*-
"""Demo for :class:`django_downloadview.HTTPDownloadView`.

Code in this package is included in documentation's :doc:`/views/http`.
Make sure to maintain both together.

"""
