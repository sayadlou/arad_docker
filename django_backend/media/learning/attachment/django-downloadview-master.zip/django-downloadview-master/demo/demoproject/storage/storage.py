from django.core.files.storage import FileSystemStorage

storage = FileSystemStorage()
