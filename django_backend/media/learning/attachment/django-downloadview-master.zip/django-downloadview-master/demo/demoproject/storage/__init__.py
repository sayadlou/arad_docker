# -*- coding: utf-8 -*-
"""Demo for :class:`django_downloadview.StorageDownloadView`.

Code in this package is included in documentation's :doc:`/views/storage`.
Make sure to maintain both together.

"""
