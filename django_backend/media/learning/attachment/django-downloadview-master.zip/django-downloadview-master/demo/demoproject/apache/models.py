"""Required to make a Django application."""
