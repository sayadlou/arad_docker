# -*- coding: utf-8 -*-
"""Demo for :class:`django_downloadview.VirtualDownloadView`.

Code in this package is included in documentation's :doc:`/views/virtual`.
Make sure to maintain both together.

"""
