# -*- coding: utf-8 -*-
"""Demo for :class:`django_downloadview.ObjectDownloadView`.

Code in this package is included in documentation's :doc:`/views/object`.
Make sure to maintain both together.

"""
