# -*- coding: utf-8 -*-
"""Demo for :class:`django_downloadview.PathDownloadView`.

Code in this package is included in documentation's :doc:`/views/path`.
Make sure to maintain both together.

"""
